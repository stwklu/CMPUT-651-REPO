Student name: Steven Weikai Lu
CCID: weikai
Student ID: 1468086